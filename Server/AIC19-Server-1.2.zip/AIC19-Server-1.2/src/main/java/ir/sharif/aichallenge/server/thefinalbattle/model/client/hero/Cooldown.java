package ir.sharif.aichallenge.server.thefinalbattle.model.client.hero;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class Cooldown {
    private String name;
    private int remCooldown;
}
