package ir.sharif.aichallenge.server.thefinalbattle.model.enums;

public enum GameState {
    INIT, PICK , MOVE, ACTION
}
