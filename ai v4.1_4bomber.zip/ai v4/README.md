# AI Challenge 2019 C++ Client
## Setup instructions
### Ubuntu
It is recommended to use CLion (JetBtains)otherwise, follow the below instructions to build the client:

```cd``` to the directory you want to save and run the code
```
git clone https://github.com/SharifAIChallenge/AIC19-Client-Cpp
cd AIC19-Client-Cpp
mkdir build
cd build
cmake ..
make

# To run the output issue:
./client/client
```





